from django.utils.translation import gettext_lazy as _

BASE_TYPES = {
    'esp-entity': _("ESP Entity"),
}
